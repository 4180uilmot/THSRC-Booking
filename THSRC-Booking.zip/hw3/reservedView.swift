import SwiftUI

struct reservedView: View {
    @State var date:Date = Date()
    @State var ticketNum:Double = 1;
    @State var idNum:String = ""
    @State var phoneNum:String = ""
    @State var email:String = ""
    @State var showAlert = false
    @State var startStationIndex:Int = 1
    @State var endStationIndex:Int = 10
    @State var carbinTypeIndex:Int = 0
    @State var ticketTypeIndex:Int = 0
    @State var seatPreferIndex:Int = 2
    
    
    
    let stations = ["南港", "台北", "板橋", "桃園", "新竹", "苗栗", "台中", "彰化", "雲林", "嘉義", "台南", "左營"]
    let cabinTypes = ["標準車廂", "商務車廂"]
    let ticketTypes = ["全票", "孩童票", "愛心票", "敬老票", "學生票"]
    let seatPrefers = ["靠窗優先", "走道優先", "無偏好"]
    
    var body: some View {
        VStack(alignment:.leading) {
            Text("高鐵訂票")
                .font(.title)
                .fontWeight(.bold)
            ScrollView {
                HStack(spacing:20) {
                    VStack {
                        Text("啟程站")
                        VStack {
                            Picker(selection: $startStationIndex, label: Text(verbatim: "啟程站"), content: {
                                ForEach(stations.indices) { item in
                                    Text(stations[item])
                                }
                            })
                        }.frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .clipped()
                    }
                    Image(systemName: "arrow.left.arrow.right")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 30, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    VStack {
                        Text("到達站")
                        VStack {
                            Picker(selection: $endStationIndex, label: Text(verbatim: "啟程站"), content: {
                                ForEach(stations.indices) { item in
                                    Text(stations[item])
                                }
                            })
                        }.frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .clipped()
                    }
                    
                }.padding()
                Spacer()
                VStack {
                    DatePicker("乘車日期", selection: $date, displayedComponents: .date)
                    DatePicker("預計乘車時間", selection: $date, displayedComponents: .hourAndMinute)
                    HStack {
                        Text("車廂種類")
                        Spacer()
                        Picker(selection: $carbinTypeIndex, label: Text("車廂種類"), content: {
                            ForEach(cabinTypes.indices) { item in
                                Text(cabinTypes[item])
                            }
                        }).pickerStyle(SegmentedPickerStyle())
                    }
                    HStack {
                        Text("票種選擇")
                        Spacer()
                        Picker(selection: $ticketTypeIndex, label: Text("票種選擇"), content: {
                            ForEach(ticketTypes.indices) { item in
                                Text(ticketTypes[item])
                            }
                        }).pickerStyle(SegmentedPickerStyle())
                    }
                    HStack {
                        Text("座位偏好")
                        Spacer()
                        Picker(selection: $seatPreferIndex, label: Text("座位偏好"), content: {
                            ForEach(seatPrefers.indices) { item in
                                Text(seatPrefers[item])
                            }
                        }).pickerStyle(SegmentedPickerStyle())
                    }
                    VStack {
                        HStack {
                            Text("乘車人數")
                            Text("\(Int(ticketNum))")
                            Spacer()
                            VStack {
                                
                            }
                            Slider(value: $ticketNum, in: 1...10, step: 1)
                            

                        }
                        Stepper("") {
                            if ticketNum < 10 {
                                ticketNum = ticketNum + 1
                            }
                        } onDecrement: {
                            if ticketNum > 1 {
                                ticketNum = ticketNum - 1
                            }
                        }
                    }
                    
                    HStack {
                        Text("身分證字號")
                        Spacer()
                        TextField("", text: $idNum)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    HStack {
                        Text("手機號碼")
                        Spacer()
                        TextField("", text: $phoneNum)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    HStack {
                        Text("電子郵箱")
                        Spacer()
                        TextField("", text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                Button("送出") {
                    showAlert = true
                }
            }
        }.padding().alert(isPresented: $showAlert, content: {
            let reservedId = Int.random(in: 10000000...99999999)
            return Alert(title: Text("訂票成功"), message: Text("訂位代號： \(Text(verbatim: "\(reservedId)"))\n取票識別碼: \(idNum)\n\(stations[startStationIndex]) -> \(stations[endStationIndex])\n乘車時間: \(Text(date, style: .time)), \(Text(date, style: .date))"), dismissButton: .cancel())
        })
    }
}

struct reservedView_Previews: PreviewProvider {
    static var previews: some View {
        reservedView()
    }
}
