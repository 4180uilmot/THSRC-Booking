//
//  hw3App.swift
//  hw3
//
//  Created by Tom Liu on 2022/11/9.
//

import SwiftUI

@main
struct hw3App: App {
    var body: some Scene {
        WindowGroup {
            reservedView()
        }
    }
}
